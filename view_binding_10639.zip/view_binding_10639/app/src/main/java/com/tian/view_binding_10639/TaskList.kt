package com.tian.view_binding_10639

object TaskList {
    val taskList = listOf<Task>(
        Task("Chapter 1", "Bangun TIdur",
            "Kebiasaan sehari - hari untuk membuat hari makin Indah"),
        Task("Chapter 2", "Nguli Genshin Impact", "Mencari Primo buat Gacha Mama Yaemika tercinta / Keging Wangi"),
        Task("Chapter 3", "Ngopi", "Habis capek Nguli, kan enak ngopi ya kan"),
        Task("Chapter 4", "dimana mama Ei?", "Buat Adu Mekanik Showcase Ayaka Pyro"),
        Task("Chapter 5", "Upload ke Tiktok",
            "Buat Pamer ke view Showcase Ayaka Pyro C6 + Bennet C6")
    )
}