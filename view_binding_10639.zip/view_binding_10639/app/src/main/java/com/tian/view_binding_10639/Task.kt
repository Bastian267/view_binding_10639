package com.tian.view_binding_10639

data class Task (val chapter:String, val title:String, val details:String){
}